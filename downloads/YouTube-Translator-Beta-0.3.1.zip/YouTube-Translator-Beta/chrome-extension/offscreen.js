let mediaStream = null;
let recorder = null;
let generation = 0;
let playing = false;
let captureTimer = null;
let currentAudio = null;
let pausedByVideo = false;

const audioQueue = [];
const CHUNK_MS = 3000;

function base64ToBlob(base64, mimeType) {
  const bytes = atob(base64);
  const buffer = new Uint8Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) buffer[i] = bytes.charCodeAt(i);
  return new Blob([buffer], { type: mimeType });
}

function stopCurrentTurkishAudio() {
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
    } catch (_) {}
    currentAudio = null;
  }
  playing = false;
}

function clearPlaybackQueue() {
  audioQueue.length = 0;
  stopCurrentTurkishAudio();
}

async function playNext() {
  if (pausedByVideo || playing || audioQueue.length === 0) return;

  playing = true;
  const item = audioQueue.shift();

  const blob = base64ToBlob(item.audio_base64, item.mime_type || "audio/mpeg");
  const url = URL.createObjectURL(blob);
  const audio = new Audio(url);
  currentAudio = audio;
  audio.playbackRate = 1.10;

  const cleanup = () => {
    URL.revokeObjectURL(url);
    if (currentAudio === audio) currentAudio = null;
    playing = false;
    playNext();
  };

  audio.onended = cleanup;
  audio.onerror = cleanup;

  try {
    await audio.play();
  } catch (e) {
    console.error("Playback failed:", e);
    cleanup();
  }
}

async function sendChunk(blob, localGeneration) {
  if (!blob || blob.size < 1200 || localGeneration !== generation) return;

  const form = new FormData();
  form.append("audio", blob, "chunk.webm");

  try {
    const response = await fetch("http://127.0.0.1:8765/dub", {
      method: "POST",
      body: form
    });

    if (!response.ok) {
      console.error("Local service error:", response.status, await response.text());
      return;
    }

    const data = await response.json();

    if (localGeneration !== generation) return;

    if (data.transcript) {
      console.log("EN:", data.transcript);
      console.log("TR:", data.translation);
    }

    if (data.audio_base64 && !pausedByVideo) {
      // Kuyruk büyümesin. Çalan sesi kesmeyiz, ama bekleyenlerden sadece
      // en yenisini tutarız.
      audioQueue.length = 0;
      audioQueue.push(data);
      playNext();
    }
  } catch (e) {
    console.error("Cannot reach local service:", e);
  }
}

function chooseMime() {
  for (const type of ["audio/webm;codecs=opus", "audio/webm"]) {
    if (MediaRecorder.isTypeSupported(type)) return type;
  }
  return "";
}

function recordOneChunk(localGeneration) {
  if (!mediaStream || localGeneration !== generation) return;

  const mimeType = chooseMime();
  const chunks = [];

  recorder = new MediaRecorder(
    mediaStream,
    mimeType ? { mimeType } : undefined
  );

  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };

  recorder.onerror = (e) => {
    console.error("MediaRecorder error:", e.error || e);
  };

  recorder.onstop = () => {
    if (localGeneration !== generation) return;

    if (chunks.length > 0) {
      const blob = new Blob(chunks, { type: mimeType || "audio/webm" });
      sendChunk(blob, localGeneration);
    }

    if (mediaStream && localGeneration === generation) {
      recordOneChunk(localGeneration);
    }
  };

  recorder.start();

  captureTimer = setTimeout(() => {
    if (
      recorder &&
      recorder.state === "recording" &&
      localGeneration === generation
    ) {
      recorder.stop();
    }
  }, CHUNK_MS);
}

async function startDub(streamId) {
  await stopDub(false);

  generation += 1;
  const localGeneration = generation;
  pausedByVideo = false;

  mediaStream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId
      }
    },
    video: false
  });

  const track = mediaStream.getAudioTracks()[0];
  if (track) track.onended = () => stopDub();

  recordOneChunk(localGeneration);
}

async function stopDub(notify = true) {
  generation += 1;

  if (captureTimer) {
    clearTimeout(captureTimer);
    captureTimer = null;
  }

  if (recorder && recorder.state !== "inactive") {
    try {
      recorder.onstop = null;
      recorder.stop();
    } catch (_) {}
  }
  recorder = null;

  if (mediaStream) {
    for (const track of mediaStream.getTracks()) track.stop();
  }
  mediaStream = null;

  clearPlaybackQueue();

  if (notify) chrome.runtime.sendMessage({ type: "DUB_STOPPED" });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.target !== "offscreen") return;

  if (message.type === "START_DUB") {
    startDub(message.streamId).catch((e) => {
      console.error("startDub failed:", e);
      chrome.runtime.sendMessage({ type: "DUB_STOPPED" });
    });
  } else if (message.type === "STOP_DUB") {
    stopDub();
  } else if (
    message.type === "YOUTUBE_VIDEO_PAUSED" ||
    message.type === "YOUTUBE_VIDEO_SEEKING"
  ) {
    pausedByVideo = true;
    clearPlaybackQueue();
  } else if (message.type === "YOUTUBE_VIDEO_PLAYING") {
    pausedByVideo = false;
  }
});
