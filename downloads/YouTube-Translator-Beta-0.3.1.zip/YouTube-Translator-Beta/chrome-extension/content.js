let boundVideo = null;

function bindVideo() {
  const video = document.querySelector("video");
  if (!video || video === boundVideo) return;

  boundVideo = video;

  video.addEventListener("pause", () => {
    chrome.runtime.sendMessage({ type: "YOUTUBE_VIDEO_PAUSED" });
  });

  video.addEventListener("play", () => {
    chrome.runtime.sendMessage({ type: "YOUTUBE_VIDEO_PLAYING" });
  });

  video.addEventListener("seeking", () => {
    chrome.runtime.sendMessage({ type: "YOUTUBE_VIDEO_SEEKING" });
  });
}

bindVideo();

const observer = new MutationObserver(bindVideo);
observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});
