const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'], documentUrls:[offscreenUrl]});
  if (contexts.length) return;
  await chrome.offscreen.createDocument({url:OFFSCREEN_DOCUMENT_PATH,reasons:['USER_MEDIA','AUDIO_PLAYBACK'],justification:'Capture YouTube tab audio and play generated Turkish dubbing.'});
}
async function isRunning(){const r=await chrome.storage.local.get(['dubRunning']);return Boolean(r.dubRunning)}
async function setRunning(v){await chrome.storage.local.set({dubRunning:v});await chrome.action.setBadgeText({text:v?'TR':''});if(v)await chrome.action.setBadgeBackgroundColor({color:'#d93025'});}
chrome.runtime.onInstalled.addListener(()=>setRunning(false));
chrome.action.onClicked.addListener(async(tab)=>{
  try{
    if(!tab?.id || !tab.url?.includes('youtube.com')){await chrome.action.setTitle({title:'Önce bir YouTube videosu aç'});return;}
    if(await isRunning()){
      await ensureOffscreenDocument();
      await chrome.runtime.sendMessage({target:'offscreen',type:'STOP_DUB'});
      await setRunning(false); return;
    }
    await ensureOffscreenDocument();
    const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:tab.id});
    await chrome.runtime.sendMessage({target:'offscreen',type:'START_DUB',streamId,tabId:tab.id});
    await setRunning(true);
  }catch(e){console.error(e);await setRunning(false);}
});
chrome.runtime.onMessage.addListener((m)=>{if(m?.type==='DUB_STOPPED')setRunning(false);});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (
    message?.type === "YOUTUBE_VIDEO_PAUSED" ||
    message?.type === "YOUTUBE_VIDEO_PLAYING" ||
    message?.type === "YOUTUBE_VIDEO_SEEKING"
  ) {
    ensureOffscreenDocument()
      .then(() => chrome.runtime.sendMessage({
        target: "offscreen",
        type: message.type
      }))
      .catch((error) => console.error("Video state forward failed:", error));
  }
});
