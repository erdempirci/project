# YouTube Translator — Beta 0.3.1

YouTube videolarındaki İngilizce konuşmayı Türkçe seslendirme olarak dinlemeyi deneyen Windows + Chrome prototipidir.

## Bu beta neyi test ediyor?
- İngilizce konuşmanın yerelde yazıya çevrilmesi
- Türkçe çeviri
- Türkçe ses üretimi
- Video duraklatıldığında sesin mümkün olduğunca senkron durması
- Gerçek kullanımda gecikme ve akıcılık

## Gereksinimler
- Windows
- Google Chrome 116 veya üzeri
- Python 3.13
- FFmpeg
- İnternet bağlantısı

## Kurulum
1. PowerShell açın ve FFmpeg kurun:
   `winget install Gyan.FFmpeg`
2. `local-server\kurulum.bat` dosyasını çalıştırın.
3. Kurulum tamamlanınca `local-server\sunucuyu_baslat.bat` dosyasını çalıştırın ve pencereyi açık bırakın.
4. Chrome'da `chrome://extensions` adresini açın.
5. **Geliştirici modu**nu açın.
6. **Paketlenmemiş öğe yükle** seçeneğinden `chrome-extension` klasörünü seçin.
7. İngilizce bir YouTube videosu açın ve eklenti ikonuna basın. Tekrar basmak dublajı durdurur.

## Gizlilik ve bağlantı notu
Konuşmayı yazıya çeviren Whisper modeli bilgisayarınızda çalışır. Bu beta sürümünde çeviri ve Türkçe ses üretimi internet tabanlı servisler kullanır. Bu nedenle tamamen çevrimdışı değildir.

## Beta sınırlamaları
Bu deneysel sürümde konuşma parçaları nedeniyle birkaç saniyelik gecikme olabilir. Uzun videolarda akıcılık veya senkron kayması görülebilir. Üretim sürümü değildir.

## Geri bildirim
Kurulum, gecikme, ses sürekliliği ve hata durumlarıyla ilgili geri bildirim özellikle değerlidir.
Project Factory: https://factory.trendflowapp.com
