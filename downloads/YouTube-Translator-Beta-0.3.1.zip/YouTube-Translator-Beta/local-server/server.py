import base64, os, subprocess, tempfile
from pathlib import Path
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from faster_whisper import WhisperModel
from deep_translator import GoogleTranslator
import edge_tts

PORT=8765; MODEL=os.environ.get('WHISPER_MODEL','base'); VOICE=os.environ.get('TTS_VOICE','tr-TR-AhmetNeural')
app=FastAPI(title='YouTube Turkish Dub Local Service',version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
print('[dub] Loading model:',MODEL)
whisper=WhisperModel(MODEL,device='cpu',compute_type='int8')
translator=GoogleTranslator(source='en',target='tr')

def to_wav(src,dst):
    subprocess.run(['ffmpeg','-y','-i',src,'-ac','1','-ar','16000',dst],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

def transcribe(path):
    segs,_=whisper.transcribe(path,language='en',vad_filter=True,beam_size=1,best_of=1,condition_on_previous_text=False)
    return ' '.join(s.text.strip() for s in segs).strip()

async def tts(text):
    c=edge_tts.Communicate(text=text,voice=VOICE,rate='+8%'); out=bytearray()
    async for ch in c.stream():
        if ch['type']=='audio': out.extend(ch['data'])
    return bytes(out)

@app.get('/health')
def health(): return {'ok':True,'model':MODEL,'voice':VOICE}

@app.post('/dub')
async def dub(audio:UploadFile=File(...)):
    data=await audio.read()
    if len(data)<1000:return {'transcript':'','translation':'','audio_base64':''}
    with tempfile.TemporaryDirectory() as tmp:
        src=str(Path(tmp)/'in.webm'); wav=str(Path(tmp)/'a.wav'); Path(src).write_bytes(data)
        try: to_wav(src,wav); text=transcribe(wav)
        except Exception as e:return JSONResponse(status_code=500,content={'error':f'audio/transcription failed: {e}'})
        if not text:return {'transcript':'','translation':'','audio_base64':''}
        try: tr=translator.translate(text)
        except Exception as e:return JSONResponse(status_code=502,content={'error':f'translation failed: {e}','transcript':text})
        try: mp3=await tts(tr)
        except Exception as e:return JSONResponse(status_code=502,content={'error':f'TTS failed: {e}','transcript':text,'translation':tr})
        return {'transcript':text,'translation':tr,'audio_base64':base64.b64encode(mp3).decode('ascii'),'mime_type':'audio/mpeg'}

if __name__=='__main__':
    import uvicorn; uvicorn.run(app,host='127.0.0.1',port=PORT)
