@echo off
cd /d "%~dp0"
echo YouTube Translator Beta 0.3.1 Kurulum
py -3.13 --version >nul 2>&1
if errorlevel 1 (echo Python 3.13 bulunamadi. PowerShell: py install 3.13 & pause & exit /b 1)
where ffmpeg >nul 2>&1
if errorlevel 1 (echo FFmpeg bulunamadi. PowerShell: winget install Gyan.FFmpeg & pause & exit /b 1)
if not exist .venv py -3.13 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo Kurulum tamamlandi.
pause
