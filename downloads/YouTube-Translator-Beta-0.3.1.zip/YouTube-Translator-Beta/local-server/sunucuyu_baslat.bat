@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Once kurulum.bat calistirin. & pause & exit /b 1)
call .venv\Scripts\activate.bat
python server.py
pause
