@echo off
powershell -NoProfile -Command "try { (Invoke-RestMethod http://127.0.0.1:8765/health) | ConvertTo-Json } catch { Write-Host 'Servis calismiyor.' -ForegroundColor Red }"
pause
